package tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import natbag.AirPort;
import natbag.Flight;

public class ReleventDeparturingFlight {

	@Test
	public void test1() {
		AirPort port= fillPort();
		StringBuffer expectedResult = new StringBuffer();
		expectedResult.append("Flight take of on: WEDNESDAY, 15/7/2020 17:07, "
				+ "flight Number: 5255, terminal: 8, Flight Company:"
				+ " ElAl,Destination: Country France, City Paris,"
				+ " arriving to air port: CDG\n");
		String actual = port.getReleventDepartures("elal", "france", "paris", "cdg", "15/07/2020 17:06", "15/07/2020 17:08", "wednesday", false);
		
		assertEquals(expectedResult.toString(), actual);
	}
	
	private AirPort fillPort() {
		AirPort port = new AirPort();
		port.addDeparture(new Flight(true, "BritishAirLine", "Britan", "London", "York", "30/10/2020 10:05", 5, 1318));
		port.addDeparture(
				new Flight(true, "TurkishAirLines", "Turkey", "Istanbul", "Sabiha", "05/11/2020 10:06", 4, 1464));
		port.addDeparture(new Flight(true, "MongoliaAir", "Mongolia", "Mongolia", "alla", "30/10/2020 10:07", 8, 1564));
		port.addDeparture(new Flight(true, "ElAl", "France", "Paris", "CDG", "15/07/2020 17:07", 8, 5255));

		return port;
	}

}
