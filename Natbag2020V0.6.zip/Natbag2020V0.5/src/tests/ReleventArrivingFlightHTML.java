package tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import natbag.AirPort;
import natbag.Flight;

public class ReleventArrivingFlightHTML {

	@Test
	public void test1() {
		AirPort port = fillPort();
		StringBuffer expectedResult = new StringBuffer();
		expectedResult.append(
				"<style> table, th, td {border: 1px solid black;border-collapse: collapse;}"
				+ "</style><h1> All Relevent Arriving Flights</h1><table><tr><th>"
				+ " Flight arrives on</th><th> Flight Number</th><th>"
				+ " Terminal</th><th> Air Line</th><th> Origins</th><th>"
				+ " Origin AirPort</th> </tr><tr><td>WEDNESDAY,"
				+ " 15/7/2020 17:07</td><td>5255</td><td>8</td>"
				+ "<td>ElAl</td><td>France, Paris</td><td>CDG</td></tr>\n" + 
				"</table>");
		String actual = port.getReleventArrivals("elal", "france", "paris", "cdg", "15/07/2020 17:06",
				"15/07/2020 17:08", "wednesday", true);

		assertEquals(expectedResult.toString(), actual);
	}

	private AirPort fillPort() {
		AirPort port = new AirPort();
		port.addArriving(new Flight(false, "RussiaTurs", "Russia", "Moscow", "Piterskiy", "06/03/2020 11:05", 2, 4351));
		port.addArriving(new Flight(false, "GermanFly", "Germany", "Berlin", "Zadoish", "06/03/2020 10:15", 5, 3652));
		port.addArriving(new Flight(false, "ClosetTours", "Narnia", "Kingdom", "Lion", "06/03/2020 11:10", 1, 2575));
		port.addArriving(new Flight(false, "ElAl", "France", "Paris", "CDG", "15/07/2020 17:07", 8, 5255));

		return port;
	}

}
