package tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import natbag.AirPort;
import natbag.Flight;

public class ReleventDeparturringFlightHTML {

	@Test
	public void test1() {
		AirPort port = fillPort();
		StringBuffer expectedResult = new StringBuffer();
		expectedResult.append(
				"<style> table, th, td {border: 1px solid black;border-collapse: collapse;}"
				+ "</style><h1> All Relevent Departuring Flights</h1><table><tr><th>"
				+ " Flight take of on</th><th> Flight Number</th><th> Terminal</th><th>"
				+ " Air Line</th><th> Destination</th><th> Landing AirPort</th> </tr><tr>"
				+ "<td>WEDNESDAY, 15/7/2020 17:07</td><td>5255</td><td>8</td><td>ElAl</td><td>France,"
				+ " Paris</td><td>CDG</td></tr>\n" + 
				"</table>");
		String actual = port.getReleventDepartures("elal", "france", "paris", "cdg", "15/07/2020 17:06",
				"15/07/2020 17:08", "wednesday", true);

		assertEquals(expectedResult.toString(), actual);
	}

	private AirPort fillPort() {
		AirPort port = new AirPort();
		port.addDeparture(new Flight(true, "BritishAirLine", "Britan", "London", "York", "30/10/2020 10:05", 5, 1318));
		port.addDeparture(
				new Flight(true, "TurkishAirLines", "Turkey", "Istanbul", "Sabiha", "05/11/2020 10:06", 4, 1464));
		port.addDeparture(new Flight(true, "MongoliaAir", "Mongolia", "Mongolia", "alla", "30/10/2020 10:07", 8, 1564));
		port.addDeparture(new Flight(true, "ElAl", "France", "Paris", "CDG", "15/07/2020 17:07", 8, 5255));

		return port;
	}


}
