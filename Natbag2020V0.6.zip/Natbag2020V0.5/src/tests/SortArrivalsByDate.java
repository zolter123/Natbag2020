package tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import natbag.AirPort;
import natbag.Flight;

public class SortArrivalsByDate {

	@Test
	public void test1() {
		AirPort port = fillPort();
		boolean isHtml=false;
		port.sortArrivingByDate();
		StringBuffer expectedResult = new StringBuffer();
		
		expectedResult.append("All the arriving flights: \n");
		expectedResult.append("Flight arriving on: FRIDAY, 6/3/2020 10:15, flight Number: 3652, terminal: 5, Flight Company: GermanFly,Flight Origins: Country Germany, City Berlin, arriving from air port: Zadoish\n" + 
				"");
		expectedResult.append("Flight arriving on: FRIDAY, 6/3/2020 11:05, flight Number: 4351, terminal: 2, Flight Company: RussiaTurs,Flight Origins: Country Russia, City Moscow, arriving from air port: Piterskiy\n" + 
				"");
		expectedResult.append("Flight arriving on: FRIDAY, 6/3/2020 11:10, flight Number: 2575, terminal: 1, Flight Company: ClosetTours,Flight Origins: Country Narnia, City Kingdom, arriving from air port: Lion\n" + 
				"");
		expectedResult.append("Flight arriving on: WEDNESDAY, 15/7/2020 17:07, flight Number: 5255, terminal: 8, Flight Company: ElAl,Flight Origins: Country France, City Paris, arriving from air port: CDG\n" + 
				"");

		
		assertEquals(expectedResult.toString(), port.showArriving(isHtml));
	}

	private AirPort fillPort() {
		AirPort port = new AirPort();
		port.addArriving(new Flight(false, "RussiaTurs", "Russia", "Moscow", "Piterskiy", "06/03/2020 11:05", 2, 4351));
		port.addArriving(new Flight(false, "GermanFly", "Germany", "Berlin", "Zadoish", "06/03/2020 10:15", 5, 3652));
		port.addArriving(new Flight(false, "ClosetTours", "Narnia", "Kingdom", "Lion", "06/03/2020 11:10", 1, 2575));
		port.addArriving(new Flight(false, "ElAl", "France", "Paris", "CDG", "15/07/2020 17:07", 8, 5255));

		return port;
	}



}
